"""
Device API that can be shared among other implementations.
"""
