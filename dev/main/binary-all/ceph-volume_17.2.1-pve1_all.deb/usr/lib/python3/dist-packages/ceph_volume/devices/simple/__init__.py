from .main import Simple # noqa
