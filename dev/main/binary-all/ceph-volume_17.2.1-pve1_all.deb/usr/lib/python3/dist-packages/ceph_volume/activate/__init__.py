from .main import Activate # noqa
