from .main import Inventory # noqa
