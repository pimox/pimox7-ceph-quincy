from .module import OSDSupport
