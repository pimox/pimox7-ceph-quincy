from .module import OSDPerfQuery
